from node import Node
from bst import BST
from avl import AVL

h = AVL()
h.insert(37)
h.insert(252)
h.insert(87)

print(str(h))
