

coordinates = (18, 13, 1)

for x in range(coordinates[0]):
    for y in range(coordinates[1]):
        for z in range(coordinates[2]):
            print(x, y, z)
